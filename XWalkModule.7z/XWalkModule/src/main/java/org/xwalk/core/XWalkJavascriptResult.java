package org.xwalk.core;

public interface XWalkJavascriptResult {
   void confirmWithResult(String var1);

   void confirm();

   void cancel();
}
